//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print("Hello Shivam")

print("Hello friends", "Hallo friends",str,separator:"&")

print(1,2,3,4,5, separator:"...")

var num1=10;
var num2=20;
let sum=num1+num2

print("Sum of \(num1) and \(num2) is \(sum)")

print("🇮🇳")

var x: Int
x=10
print("value of \(x)")

var greet: String?               //Optional Binding

greet="Hello"

print("\(String(describing: greet))")


if greet != nil{
    
    print(greet!)
}else{
    print("Greet is nil")
}

var temperature: Int!

print(temperature)

if temperature != nil{
    print("\(temperature) is not nil")
    
}else {
    print("Temperature is nil")
    
}

let PI: Float=3.14

print("\(PI)")

let friends: [String] = ["Alay","Abhi","Akash","Aman"]

for frnd in friends{
    print("Friend: \(frnd)")
}
 var j = 5
switch j{
case 1...10:
    print("1 to 10")
case 10:
    print("ten")
case 20:
    print("twenty")
case 40,70,80:
    print("forty or seventy")
case 81..<100:
    print("81 to 100")
default:
    print("Not Supported")
}

let coordinate=(10,20)

switch coordinate {
case (0,0):
    print("no canvas")
case(10,20):
    print("on Center")
    fallthrough
case(1...10, 1...20):
    print("Within Canvas")
case (_,20):
    print("Y axis")
case (10,_):
    print("X axis")
default:
    print("canvas unavailable")
}

let range=1...5
print("\(range) contains 3: ", range.contains(3))
print("\(range) contains 7: ", range.contains(7))
print("\(range) lowerbound: ", range.lowerBound)
print("\(range) upperbound: ", range.upperBound)
