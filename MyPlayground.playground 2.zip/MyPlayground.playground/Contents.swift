//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

//multiline str
var greet = """
Haalo friends,
How are you doing!
Cludy weather...
Boring class
Funny Friends
"""

print(greet)

let db = """
Saa
Re
Ga
Ma
Paa
Dha
Ni
saa
"""
print(db)

//swift unicode sequance for emojis
let mood = "\u{1f496}"
print(mood)

if mood.isEmpty{
print("No mood!")
}
else
{greet += mood
}
print (greet)

//str obj
var team = String()
team = "Croatia"
print(team)

//to get individual char of the string
for i in team{
    print(i)
}
//chaacer is class datatype
var initial : Character = "D"
team.append(initial)
print(team)

team.append(" Go Go Go")
print(team)
//to get the length of str

print("Length of team :", team.count)

//startIndex will give u th obj of that index class so we have to put it like this:
print("Start Index of team: \(team[team.startIndex])")
//u cnt get the endIndex chra
//print("end Index of Team : \(team[team.endIndex])")

//index method=
//index after \ before

print("last char of team: \(team[team.index(before: team.endIndex)])")

print("Some Character: \(team[team.index(after:team.startIndex)])")

print("4th char: \(team[team.index(team.startIndex,offsetBy: 3)])")
//3rd char means 0 ,1,2,3

print("6th char: \(team[team.index(team.endIndex,offsetBy: -5)])")

var idx = team.index(team.endIndex,offsetBy: -5)
print("\(idx)")


for (index,value) in team.enumerated(){
    print("Index: \(index) --- Value: \(value)")
}

print(team)

team.insert("!", at: team.endIndex)
team.insert(contentsOf: "Win IT ", at: team.endIndex)

var idx1=team.index(of: "D") ?? team.endIndex
team.remove(at: idx1)
print(team)

var idxG=team.index(of: "G") ?? team.endIndex

team.removeSubrange(team.startIndex..<idxG)

var idxI=team.index(of: "i") ?? team.endIndex
var win = team[team.startIndex..<idxI]
print(team)




















